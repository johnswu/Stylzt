<?php


require_once( dirname(dirname(dirname( dirname( dirname( dirname( __FILE__ )))))) . '/wp-load.php' );



?>